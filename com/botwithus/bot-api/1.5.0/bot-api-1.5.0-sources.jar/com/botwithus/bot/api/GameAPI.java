package com.botwithus.bot.api;

import com.botwithus.bot.api.component.Components;
import com.botwithus.bot.api.domain.ActionAPI;
import com.botwithus.bot.api.domain.DrawAPI;
import com.botwithus.bot.api.domain.NavigationAPI;
import com.botwithus.bot.api.domain.SystemAPI;
import com.botwithus.bot.api.domain.VariableAPI;
import com.botwithus.bot.api.entities.GroundItems;
import com.botwithus.bot.api.entities.HintArrows;
import com.botwithus.bot.api.entities.Npcs;
import com.botwithus.bot.api.entities.Players;
import com.botwithus.bot.api.entities.Projectiles;
import com.botwithus.bot.api.entities.SceneObjects;
import com.botwithus.bot.api.entities.WorldMapElements;
import com.botwithus.bot.api.gameval.GamevalIndex;
import com.botwithus.bot.api.gameval.GamevalType;
import com.botwithus.bot.api.input.InputDialog;
import com.botwithus.bot.api.input.KeyStroke;
import com.botwithus.bot.api.inventory.ActionTypes;
import com.botwithus.bot.api.inventory.Backpack;
import com.botwithus.bot.api.inventory.Bank;
import com.botwithus.bot.api.inventory.Equipment;
import com.botwithus.bot.api.model.EntityKind;
import com.botwithus.bot.api.model.EntityRead;
import com.botwithus.bot.api.model.EnumType;
import com.botwithus.bot.api.model.GameAction;
import com.botwithus.bot.api.model.Headbar;
import com.botwithus.bot.api.model.HintArrow;
import com.botwithus.bot.api.model.OverheadText;
import com.botwithus.bot.api.model.PlayerAppearance;
import com.botwithus.bot.api.model.WorldMapElement;
import com.botwithus.bot.api.model.ItemType;
import com.botwithus.bot.api.model.LocationType;
import com.botwithus.bot.api.model.LoginState;
import com.botwithus.bot.api.model.NpcType;
import com.botwithus.bot.api.model.PlayerStat;
import com.botwithus.bot.api.model.QuestType;
import com.botwithus.bot.api.model.ScriptResult;
import com.botwithus.bot.api.model.Component;
import com.botwithus.bot.api.model.ComponentOps;
import com.botwithus.bot.api.model.ComponentRef;
import com.botwithus.bot.api.model.ComponentTreeNode;
import com.botwithus.bot.api.model.SequenceType;
import com.botwithus.bot.api.model.SpotAnimation;
import com.botwithus.bot.api.model.StructType;
import com.botwithus.bot.api.snapshot.GameSnapshot;
import com.botwithus.bot.api.snapshot.LocalPlayer;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.OptionalInt;

/**
 * Slim RPC-shaped surface for talking to the game producer. After the
 * GameAPI rewrite (Path B) most legacy reads moved to
 * {@link com.botwithus.bot.api.snapshot.GameSnapshot} (obtained via
 * {@link Client#snapshot()}); only mutations, the two state probes that
 * the producer always handles, and the cache-type lookups (slice 5
 * stubs) live here.
 *
 * <p>Domain split:</p>
 * <ul>
 *   <li>{@link SystemAPI} — pipe ping / introspection</li>
 *   <li>{@link ActionAPI} — action queue + behavior modifiers</li>
 *   <li>{@link NavigationAPI} — walker, pathfinder queries, region cache</li>
 *   <li>{@link VariableAPI} — on-demand varp / varbit / varc reads</li>
 *   <li>{@link DrawAPI} — debug drawing over the client ({@code api.draw()})</li>
 * </ul>
 *
 * <p>Per-tick reads of game state (local player, NPCs, players, inventories)
 * go through {@link Client#snapshot()}; transient changes (varp/varbit deltas,
 * chat) arrive as events on the {@link com.botwithus.bot.api.event.EventBus}.
 * On-demand variable reads (current value of an arbitrary varp/varbit/varc)
 * live on {@link VariableAPI} below.</p>
 *
 * @see ScriptContext#getGameAPI()
 */
public interface GameAPI extends SystemAPI, ActionAPI, NavigationAPI, VariableAPI, DrawAPI {

    /**
     * Value the gameval-named variable reads return when the name does not
     * resolve — the same "no value" sentinel {@link #getVarp(int)} yields for a
     * varp that does not exist or could not be read.
     *
     * <p>It is <b>not</b> the value of an unset varp. An unset varp reads its type
     * default, which is usually {@code 0} and, for object-typed varps, is itself
     * {@code -1}; a set varp can hold {@code -1} too. So {@code -1} never means
     * "unset" on its own: ask {@link #readVarp(int)} or {@link #varpState(int)}.</p>
     */
    int UNRESOLVED_VARIABLE = -1;

    /** Sub-component id meaning "the component itself" in a component trigger. */
    int TOP_LEVEL_COMPONENT = -1;

    // ---------------------------------------------------------------- Snapshot

    /**
     * Returns a tick-scoped read view over the producer's published snapshot,
     * or {@code null} if no shared-memory region is bound (e.g. tests using
     * the legacy 1-/2-arg {@code GameAPIImpl} constructor). Same instance
     * shape as {@link Client#snapshot()}; surfaced here so the entity query
     * facades ({@link #npcs()}, {@link #players()}) and skill helpers
     * ({@link #getLocalPlayer()}, {@link #getPlayerStat(int)}) can read
     * snapshot fields without forcing scripts to thread {@code Client}
     * through every helper.
     *
     * <p>The returned view is bounded to the current tick — don't cache it.
     * Each call resolves the published front buffer.</p>
     */
    GameSnapshot snapshot();

    /**
     * Convenience shim — delegates to {@code snapshot().isInterfaceOpen(ifaceId)}.
     * Kept so call sites that pre-date the rewrite ({@code api.isInterfaceOpen(...)})
     * keep compiling. New code should go through {@link GameSnapshot} directly.
     */
    default boolean isInterfaceOpen(int ifaceId) {
        GameSnapshot s = snapshot();
        return s != null && s.isInterfaceOpen(ifaceId);
    }

    // ---------------------------------------------------------------- Gameval names

    /**
     * Resolves gameval symbolic names — the game's own stable names for items,
     * scenery, NPCs, interfaces, components and variables — to ids. Never
     * {@code null}: when no index is deployed this returns
     * {@link GamevalIndex#empty()}, whose lookups all come back empty.
     *
     * <p>Backed by an out-of-band {@code gameval.sqlite} in
     * {@code ~/.botwithus/native/}, so a game renumber is fixed by refreshing
     * that file rather than by editing scripts. The same instance is shared by
     * every connected client.</p>
     *
     * <pre>{@code
     * int yew = api.gamevals().require(GamevalType.ITEM, "YEW_LOGS");
     * }</pre>
     */
    default GamevalIndex gamevals() {
        return GamevalIndex.empty();
    }

    /**
     * Value of a player variable named by its gameval, e.g.
     * {@code "WOODCUTTING_WOODBOX_LASTUSED_TIER"}. Convenience over
     * {@link #getVarp(int)}.
     *
     * <p>Returns {@link #UNRESOLVED_VARIABLE} when the name does not resolve —
     * the same value {@link #getVarp(int)} yields for a varp that does not exist
     * or could not be read — so a host with no gameval index deployed degrades
     * rather than killing the script. An unset varp is different: it reads its
     * type default. Use {@code gamevals().require(...)} explicitly when you would
     * rather fail fast.</p>
     */
    default int getVarp(String gameval) {
        OptionalInt id = gamevals().id(GamevalType.VARP, gameval);
        return id.isPresent() ? getVarp(id.getAsInt()) : UNRESOLVED_VARIABLE;
    }

    /**
     * Full 64-bit value of a player variable named by its gameval. Convenience over
     * {@link #getVarpLong(int)}; {@link #UNRESOLVED_VARIABLE} when the name does not
     * resolve.
     */
    default long getVarpLong(String gameval) {
        OptionalInt id = gamevals().id(GamevalType.VARP, gameval);
        return id.isPresent() ? getVarpLong(id.getAsInt()) : UNRESOLVED_VARIABLE;
    }

    /**
     * Value of a variable bit named by its gameval, e.g.
     * {@code "ZAROS_SPELLBOOK"}. Convenience over {@link #getVarbit(int)};
     * {@link #UNRESOLVED_VARIABLE} when the name does not resolve.
     */
    default int getVarbit(String gameval) {
        OptionalInt id = gamevals().id(GamevalType.VARBIT, gameval);
        return id.isPresent() ? getVarbit(id.getAsInt()) : UNRESOLVED_VARIABLE;
    }

    /**
     * Value of an integer client variable named by its gameval. Convenience
     * over {@link #getVarcInt(int)}; {@link #UNRESOLVED_VARIABLE} when the name
     * does not resolve.
     */
    default int getVarcInt(String gameval) {
        OptionalInt id = gamevals().id(GamevalType.VAR_CLIENT, gameval);
        return id.isPresent() ? getVarcInt(id.getAsInt()) : UNRESOLVED_VARIABLE;
    }

    // ---------------------------------------------------------------- Entity queries

    /**
     * NPC query facade. Singleton per {@link GameAPI}; returns the same
     * instance every call so the underlying {@code NpcType} cache is shared.
     */
    Npcs npcs();

    /**
     * Player query facade. Singleton per {@link GameAPI}.
     */
    Players players();

    // ---------------------------------------------------------------- Inventory facades

    /** Backpack facade. Singleton per {@link GameAPI}. */
    Backpack backpack();

    /** Bank facade. Singleton per {@link GameAPI}. */
    Bank bank();

    /** Worn equipment facade. Singleton per {@link GameAPI}. */
    Equipment equipment();

    /**
     * Per-item obj vars for every filled slot of a container — the per-instance
     * variables an item carries in its slot's {@code ObjVarDomain}
     * (augmentation XP, charges, etc.), distinct from the global player/client
     * var domains. Read on demand over the RPC pipe (the obj-var hashmaps are
     * walked on the game thread). Returns {@code slot -> (varId -> value)}; an
     * empty map when nothing in the container carries obj vars.
     *
     * @param invId container id (e.g. 93 = backpack, 94 = equipment)
     */
    Map<Integer, Map<Integer, Integer>> getObjVars(int invId);

    /**
     * Per-item obj vars for a single container slot. Returns {@code varId ->
     * value}, or an empty map when the slot is empty or carries no obj vars.
     *
     * @param invId container id
     * @param slot  0-based slot index
     */
    Map<Integer, Integer> getObjVars(int invId, int slot);

    // ---------------------------------------------------------------- Scene queries

    /** Scene-object query facade. Singleton per {@link GameAPI}. */
    SceneObjects objects();

    /** Ground-item query facade. Singleton per {@link GameAPI}. */
    GroundItems groundItems();

    /**
     * In-flight projectile query facade (v17+). Singleton per {@link GameAPI}.
     *
     * <p>Read-only: projectiles carry no menu actions and no cache definition,
     * so the entities this yields have no {@code interact()} and no
     * {@code name()}. See {@link com.botwithus.bot.api.entities.Projectile}.</p>
     */
    Projectiles projectiles();

    /**
     * Low-level RPC: every world-anchored spot animation currently playing
     * (graphics on a tile, not on an entity). Hits the producer on every call
     * — fetch once per tick and filter client-side.
     *
     * <p>Plane is {@link SpotAnimation#UNKNOWN_PLANE} when the producer reply
     * omits it.</p>
     */
    List<SpotAnimation> querySpotAnims();

    // Scene entity queries are SHM-backed as of v15 — read them via the
    // {@link #objects()} / {@link #groundItems()} facades, which in turn
    // pull from {@link #snapshot()}. The old query_locations /
    // query_ground_items RPCs were retired.

    /** World-map element query facade. Singleton per {@link GameAPI}. */
    WorldMapElements mapElements();

    /**
     * Low-level RPC: ask the producer for cache-resident world map elements
     * matching {@code filter}. The map shape is the same one
     * {@link WorldMapElements.Query} accumulates. Most scripts go through
     * {@link #mapElements()} instead. Stub-empty until producer iteration
     * lands.
     */
    List<WorldMapElement> queryWorldMapElements(Map<String, Object> filter);

    /**
     * Single world-map element by {@link WorldMapElement#id() id}, or
     * {@code null} when not found. Default implementation scans the
     * {@link #queryWorldMapElements unfiltered query} result client-side, so
     * it inherits the producer-side stub-empty behaviour — once cache
     * iteration lands, this returns real data without a code change.
     *
     * <p>Convenience for callers that already know the id (e.g. resolving a
     * named-location catalog entry). For map searches with filters use
     * {@link #mapElements()}.</p>
     */
    default WorldMapElement getWorldMapElement(int id) {
        for (WorldMapElement e : queryWorldMapElements(Map.of())) {
            if (e.id() == id) {
                return e;
            }
        }
        return null;
    }

    // ---------------------------------------------------------------- Local player & skills

    /**
     * The local player, with {@link LocalPlayer#currentHealth()} and
     * {@link LocalPlayer#maxHealth()} filled in. Returns {@code null} when not
     * in-game (matches snapshot semantics).
     *
     * <p>Otherwise the same record {@code snapshot().self()} returns — but
     * health is not in the mapping, so filling it costs one batched varp read
     * over the pipe. That read is cached per server tick, so calling this in a
     * loop costs at most one round-trip per 600ms tick; both values degrade to
     * {@link LocalPlayer#HEALTH_UNKNOWN} if the read doesn't land. Callers that
     * only want position, skills or animation should prefer
     * {@code snapshot().self()}, which never touches the pipe.</p>
     */
    LocalPlayer getLocalPlayer();

    /**
     * No-plane convenience for {@link NavigationAPI#walkWorldPathAsync(int, int, int)}
     * — uses the local player's current plane. With no local player no walk
     * starts, as that method documents. Lives here (not on
     * {@code NavigationAPI}) because it needs {@link #snapshot()}.
     *
     * <p>Reads the plane off the snapshot rather than
     * {@link #getLocalPlayer()}: only the plane is wanted, and the health read
     * that accessor pays for would be a round-trip spent on nothing.</p>
     */
    default void walkWorldPath(int x, int y) {
        GameSnapshot snap = snapshot();
        LocalPlayer lp = snap == null ? null : snap.self();
        walkWorldPathAsync(x, y, lp == null ? 0 : lp.plane());
    }

    /**
     * Returns one of the local player's skill stats by skill type id.
     * {@code null} when not in-game or the skill isn't in the published
     * skills array. Ids match the in-game {@code StatType.id} (e.g. 25
     * for Divination, 26 for Invention, 6 for Magic); take them from
     * {@link com.botwithus.bot.api.util.Skills} rather than writing the
     * number.
     *
     * <p>Read out of the snapshot — no RPC round-trip.</p>
     */
    PlayerStat getPlayerStat(int skillId);

    // ---------------------------------------------------------------- State probes

    /**
     * Returns the producer's monotonically increasing game cycle counter.
     * Backed by the {@code get_game_cycle} RPC.
     */
    int getGameCycle();

    /**
     * Returns the producer's current login state. Backed by the
     * {@code get_login_state} RPC.
     */
    LoginState getLoginState();

    // ---------------------------------------------------------------- Login / breaks (mutations)

    /** Initiates a world hop to the given world id. */
    void setWorld(int worldId);

    /**
     * Requests a login state transition.
     *
     * @param oldState the expected current state, or {@code <= 0} to skip the check
     * @param newState the desired new state
     */
    void changeLoginState(int oldState, int newState);

    /**
     * Triggers a login from the login screen to the lobby.
     *
     * @throws RuntimeException if the client is not on the login screen
     */
    void loginToLobby();

    /** Schedules a break (action-queue gate) for the given duration. */
    void scheduleBreak(int durationMs);

    /** Interrupts any currently active break. */
    void interruptBreak();

    /** Returns whether the producer's auto-login state machine is enabled. */
    boolean getAutoLogin();

    /** Enables or disables the producer's auto-login state machine. */
    void setAutoLogin(boolean enabled);

    // ---------------------------------------------------------------- Client script execution

    /**
     * Obtains a producer-side handle to a client script for repeated execution.
     * Release with {@link #destroyScriptHandle(long)} when done.
     */
    long getScriptHandle(int scriptId);

    /**
     * Executes a previously-obtained client script handle.
     *
     * @param handle     handle from {@link #getScriptHandle(int)}
     * @param intArgs    integer args, or {@code null}
     * @param stringArgs string args, or {@code null}
     * @param returns    expected return-type descriptors, or {@code null}
     */
    ScriptResult executeScript(long handle, int[] intArgs, String[] stringArgs, String[] returns);

    /** Releases a script handle. */
    void destroyScriptHandle(long handle);

    /**
     * Fires a component's CS2 event trigger (click / key / ...) by event type,
     * reproducing the engine's own component-event path. Enqueued on the action
     * queue and run on the game thread; a component that carries no trigger of
     * the requested type is a silent no-op.
     *
     * @param interfaceId owning interface id
     * @param componentId component id
     * @param subId       sub-component id, or {@code -1} for the top-level component
     * @param triggerType event type — {@code 9} = click, {@code 10} = key
     *                    (see {@code ActionTypes.TRIGGER_TYPE_*})
     * @param arg         type-dependent argument. For key triggers, either form:
     *                    <ul>
     *                      <li>a bare Jagex <b>key code</b> ({@code 0..0xFFFF}, e.g.
     *                          {@link KeyStroke#CODE_ENTER}): sent as a key-down with
     *                          no character, {@code (arg << 16) | 0};</li>
     *                      <li>a packed {@link KeyStroke#packed()}
     *                          ({@code (keyCode << 16) | keyChar}, non-zero high
     *                          half): sent unchanged. Use this to type a character
     *                          ({@code KeyStroke.character(c).packed()}).</li>
     *                    </ul>
     *                    See {@link KeyStroke#keyTriggerArg(int)}. For click triggers,
     *                    packed {@code (x << 16) | y} component-relative press
     *                    coordinates. {@code 0} if unused.
     */
    void fireComponentTrigger(int interfaceId, int componentId, int subId, int triggerType, int arg);

    /**
     * Fires a component's key (type-10) CS2 trigger once per stroke, in order, as
     * a single batched action-queue request (one RPC round-trip). The agent
     * dispatches one queued action per game tick, so {@code n} strokes take
     * {@code n} ticks to land. A component with no key trigger — an input dialog
     * that has already closed, for one — drops the strokes silently.
     *
     * <p>For the game's own input dialog, {@link #inputDialog()} is the checked
     * way in: it validates what it types against the dialog's mode and submits.</p>
     *
     * @return the number of strokes queued
     */
    default int fireKeys(int interfaceId, int componentId, List<KeyStroke> keys) {
        if (keys.isEmpty()) {
            return 0;
        }
        List<GameAction> batch = keys.stream()
                .map(key -> GameAction.componentTrigger(interfaceId, componentId,
                        TOP_LEVEL_COMPONENT, ActionTypes.TRIGGER_TYPE_KEY, key.packed()))
                .toList();
        return queueActions(batch);
    }

    /**
     * Types {@code input} into a component through its key (type-10) CS2 trigger,
     * one {@link KeyStroke#character(char)} per character, batched as by
     * {@link #fireKeys}. <b>Types only — it does not submit</b>; follow it with
     * {@code fireKeys(interfaceId, componentId, List.of(KeyStroke.ENTER))}, or use
     * {@link #inputDialog()}, which types and submits in one batch. A {@code null}
     * or empty {@code input} queues nothing.
     *
     * @throws IllegalArgumentException when {@code input} holds a character that
     *                                  is not printable ASCII
     */
    default void fireKeyTrigger(int interfaceId, int componentId, String input) {
        if (input == null || input.isEmpty()) {
            return;
        }
        List<KeyStroke> keys = input.chars().mapToObj(c -> KeyStroke.character((char) c)).toList();
        fireKeys(interfaceId, componentId, keys);
    }

    /**
     * The game's text/amount input dialog (withdraw-X, add-friend, ...). Singleton
     * per {@link GameAPI}.
     */
    InputDialog inputDialog();

    // ---------------------------------------------------------------- Player appearance

    /**
     * Reads one loaded player's applied appearance (one pipe round-trip, answered on the game
     * thread). Never {@code null}: when the agent cannot read it, the result carries the reason in
     * {@link PlayerAppearance#status()} and no data. Check {@link PlayerAppearance#isAvailable()}.
     *
     * <p><b>Slots are in the client's order, not wearpos</b>; match worn items by item id
     * ({@link PlayerAppearance#isWearing(int)}). {@link PlayerAppearance#gender()} is inferred.</p>
     *
     * @param serverIndex the player's server index, as on {@code Player.serverIndex()}
     * @throws IllegalArgumentException when the agent rejects the argument itself
     */
    PlayerAppearance getPlayerAppearance(int serverIndex);

    // ---------------------------------------------------------------- Entity reads (wire v25)
    //
    // On the beta client channel all three always answer EntityReadStatus.CHANNEL_UNSUPPORTED. That
    // is a normal result, not a fault, and it does not throw.

    /**
     * The text above an entity right now. Each call is a pipe round-trip onto the game thread.
     *
     * <p>A reading of {@code Optional.empty()} with {@link EntityRead#isAvailable()} true means the
     * entity is silent, including a text past its expiry that the client has not cleared yet. A
     * refusal (not in the world, nothing loaded at that index, a timeout) comes back as
     * {@link EntityRead#status()}, so "silent" and "could not read" stay apart. A player's text has
     * not been read live yet; the same client field has, on NPCs.</p>
     *
     * @param kind        which entity table {@code serverIndex} is in
     * @param serverIndex the entity's server index
     * @throws IllegalArgumentException when the agent rejects the argument itself
     */
    EntityRead<Optional<OverheadText>> getOverheadText(EntityKind kind, int serverIndex);

    /**
     * Every headbar entry on an entity, slot by slot, with no liveness filter. Each call is a pipe
     * round-trip onto the game thread. An available empty list means it has no bars; a refusal comes
     * back as {@link EntityRead#status()}.
     *
     * @param kind        which entity table {@code serverIndex} is in
     * @param serverIndex the entity's server index
     * @throws IllegalArgumentException when the agent rejects the argument itself
     */
    EntityRead<List<Headbar>> getHeadbars(EntityKind kind, int serverIndex);

    /**
     * Low-level RPC: every hint arrow the client holds. Most scripts go through
     * {@link #hintArrows()}, which collapses a refusal to an empty list; this is how to tell
     * "no arrows" from "could not read".
     */
    EntityRead<List<HintArrow>> queryHintArrows();

    /**
     * A new hint-arrow query. Each terminal issues one {@link #queryHintArrows()} and filters in
     * Java, because the RPC takes no filters.
     */
    default HintArrows.Query hintArrows() {
        return HintArrows.query(this);
    }

    // ---------------------------------------------------------------- Interface components

    /**
     * Interface-component query facade — the high-level, fluent entry point for
     * inspecting interface components (parallel to {@link #npcs()} /
     * {@link #mapElements()}). Singleton per {@link GameAPI}. Most scripts use
     * this rather than the low-level {@link #getComponent} /
     * {@link #getInterfaceTree} primitives below.
     */
    Components components();

    // ---------------------------------------------------------------- Interface tree walk (low-level)

    /**
     * Returns the component at {@code (interfaceId, componentId)} or
     * {@code null} when no such component is loaded. Each call is a pipe
     * round-trip — Phase 1 has no consumer-side cache.
     *
     * <p>Phase 1 starter set covers identity + post-layout geometry only;
     * text, item, sprite, hidden, color, font and other per-type fields
     * are not yet surfaced and arrive in later slices.</p>
     */
    Component getComponent(int interfaceId, int componentId);

    /**
     * Batch counterpart of {@link #getComponent(int, int)}. The producer
     * walks every target on a single game-thread visit, collapsing the
     * latency of N independent {@code getComponent} calls (one tick each)
     * into one tick total.
     *
     * <p>The producer hard-caps the per-call batch (currently 64). Oversize
     * inputs are silently truncated by the producer, so the returned list
     * may be shorter than {@code refs}; callers that need more than the cap
     * should split into chunks themselves.</p>
     *
     * @param refs components to resolve, in the desired result order
     * @return one element per resolved ref, in input order; {@code null}
     *         entries signal "not found" (matches the single-component
     *         contract). Length may be less than {@code refs.size()} when
     *         the producer cap is exceeded.
     */
    List<Component> getComponents(List<ComponentRef> refs);

    /**
     * The live right-click ops of a component, or of one sub of it: the ops the client's
     * menu lists now, by name and op number, and the op-flags word that says which of them
     * reach the server. For a backpack slot pass the backpack grid and the slot index as
     * {@code sub}. Each call is a pipe round-trip.
     *
     * <p>Use this to turn an option name into the op number a {@code COMPONENT} action
     * needs. An item's cache option list ({@link ItemType#inventoryOptions()}) is not that
     * mapping: its slot index is not the op the client sends.</p>
     *
     * @param sub the sub-component index; for an inventory grid, the 0-based slot
     * @return the ops, or {@link ComponentOps#NONE} when the component does not resolve
     *         or the agent refuses the call (an agent too old to have it, for one)
     */
    ComponentOps getComponentOps(int interfaceId, int componentId, int sub);

    /**
     * Returns the static (cache-defined) child component ids of
     * {@code (interfaceId, componentId)}. Each call is a pipe round-trip — Phase 1
     * has no consumer-side cache, so don't loop this in tight code yet.
     *
     * <p>The list contains each child's own {@code componentId} within the same
     * interface; entries equal to {@code -1} indicate a child whose packed
     * address slot is unset (the producer surfaces the game's {@code 0xFFFF}
     * sentinel as -1). Returns an empty list when the parent is unresolvable
     * (interface not loaded, component slot empty, or no static children).</p>
     */
    List<Integer> getStaticChildren(int interfaceId, int componentId);

    /**
     * Returns the dynamic (script-spawned) child component ids of
     * {@code (interfaceId, componentId)}. Same shape and caveats as
     * {@link #getStaticChildren(int, int)}; this is the path embedded
     * dropdowns and other transient sub-trees travel through.
     */
    List<Integer> getDynamicChildren(int interfaceId, int componentId);

    /**
     * Returns the component at {@code (interfaceId, componentId)} and its entire
     * descendant subtree, flattened breadth-first, in a single pipe round-trip.
     * Empty list when the root doesn't resolve.
     *
     * <p>Each {@link ComponentTreeNode} carries its component plus a
     * {@code parentIndex} into the same list ({@code -1} for the root). The
     * producer follows the live {@code Component*} children vectors, so the walk
     * spans mounted sub-interface boundaries — a child's own interface id rides
     * along in {@code component.ifaceId()}, which per-node
     * {@link #getStaticChildren} cannot follow.</p>
     *
     * <p>Most scripts use {@link #components()} instead; this is the seam the
     * {@link Components} facade drives.</p>
     */
    List<ComponentTreeNode> getInterfaceTree(int interfaceId, int componentId);

    /**
     * Locate the deepest visible component under a screen-space coordinate, or
     * {@code null} when nothing is there. Coordinates are raw screen pixels
     * (the value of Win32 {@code GetCursorPos}); the producer runs inside the
     * game process and converts to client-window space itself.
     *
     * <p>The producer walks every open sub-interface on the game thread and
     * picks the component with the greatest tree depth whose post-layout AABB
     * contains the point — ties broken by the smaller AABB. Only components
     * that are on screen are candidates: a node whose
     * {@link Component#isVisibleGlobal()} is false is skipped, and with it every
     * node under it, so the text inside a collapsed panel cannot be picked
     * through the panel. (On a client channel that cannot read visibility,
     * every node reports on screen and the whole tree stays pickable.) Useful
     * for debugger "pick on screen" tools and for scripters who know a
     * feature's location but not its component id.</p>
     */
    Component findComponentAt(int screenX, int screenY);

    // ---------------------------------------------------------------- Config-type lookups (slice 5: stubs)

    /**
     * @apiNote slice 5 stub — producer returns a sentinel response until
     *          the real cache-backed lookup lands.
     */
    ItemType getItemType(int id);

    /** @apiNote slice 5 stub — see {@link #getItemType(int)}. */
    NpcType getNpcType(int id);

    /** @apiNote slice 5 stub — see {@link #getItemType(int)}. */
    LocationType getLocationType(int id);

    /** @apiNote slice 5 stub — see {@link #getItemType(int)}. */
    EnumType getEnumType(int id);

    /** @apiNote slice 5 stub — see {@link #getItemType(int)}. */
    StructType getStructType(int id);

    /** @apiNote slice 5 stub — see {@link #getItemType(int)}. */
    SequenceType getSequenceType(int id);

    /** @apiNote slice 5 stub — see {@link #getItemType(int)}. */
    QuestType getQuestType(int id);
}
