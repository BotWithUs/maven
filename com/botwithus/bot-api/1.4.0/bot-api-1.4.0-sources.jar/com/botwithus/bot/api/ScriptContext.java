package com.botwithus.bot.api;

import com.botwithus.bot.api.debug.ScriptContextPublisher;
import com.botwithus.bot.api.event.EventBus;
import com.botwithus.bot.api.isc.MessageBus;
import com.botwithus.bot.api.isc.SharedState;

import java.util.Optional;

/**
 * Context object passed to {@link BotScript#onStart} providing access to
 * the game API and the event bus.
 *
 * @see BotScript
 * @see GameAPI
 * @see EventBus
 * @see MessageBus
 */
public interface ScriptContext {

    /**
     * Returns the game API for interacting with the game client.
     *
     * @return the {@link GameAPI} instance
     */
    GameAPI getGameAPI();

    /**
     * Returns the event bus for subscribing to and publishing game events.
     *
     * @return the {@link EventBus} instance
     */
    EventBus getEventBus();

    /**
     * Returns the message bus for inter-script communication.
     *
     * @return the {@link MessageBus} instance
     */
    MessageBus getMessageBus();

    /**
     * Returns the shared state store for inter-script data sharing.
     *
     * @return the {@link SharedState} instance
     */
    SharedState getSharedState();

    /**
     * Returns the navigation interface for blocking walk operations.
     * Walk methods block the calling thread until arrival, cancellation,
     * failure, or timeout, but do not block the pipe.
     *
     * @return the {@link Navigation} instance
     */
    Navigation getNavigation();

    /**
     * Returns the debug publisher bound to this script. Calls into the returned
     * publisher fan out to whoever is subscribed to the agent's {@code script.context}
     * broker topic (primarily {@code NXTDebugger}).
     *
     * <p>The default implementation returns {@link ScriptContextPublisher#NOOP};
     * runtimes that have wired a channel override this to return a per-script
     * tagged publisher.</p>
     */
    default ScriptContextPublisher getScriptContext() {
        return ScriptContextPublisher.NOOP;
    }

    /**
     * Whether the user (or the host) has asked this script to stop.
     *
     * <p>Poll this inside any loop or wait that could run for more than a
     * moment, and return from {@code onLoop} when it goes true. The runtime
     * also interrupts the script thread, but interruption is only observed
     * between loops — a script that waits <em>inside</em> {@code onLoop} won't
     * see it:</p>
     *
     * <pre>{@code
     * @Override
     * public int onLoop() {
     *     while (!bank.isOpen()) {
     *         if (ctx.isStopRequested()) {
     *             return -1;          // clean exit
     *         }
     *         Thread.sleep(100);
     *     }
     *     ...
     * }
     * }</pre>
     *
     * <p>Ignoring this is not fatal but is not free either: a script that won't
     * exit is eventually revoked — every subsequent game call throws
     * {@link com.botwithus.bot.api.runtime.ScriptRevokedException} — and then
     * quarantined, which keeps its thread alive and its classloader pinned for
     * the rest of the session.</p>
     *
     * <p>Defaults to {@code false} for contexts that aren't runtime-backed
     * (test mocks), so a script polling it in a unit test simply never stops.</p>
     */
    default boolean isStopRequested() {
        return false;
    }

    /**
     * Request that this script terminate. Idempotent. The runner will let the
     * current {@link BotScript#onLoop} iteration finish, then transition through
     * {@link BotScript#onStop} as usual — same lifecycle a {@code -1} return from
     * {@code onLoop} produces, but reachable from any depth in the script.
     *
     * <p>This is the push side of {@link #isStopRequested()}, and it takes the
     * same path a user Stop does: afterwards {@code isStopRequested()} returns
     * {@code true} and the script thread is interrupted, so a sleep or wait
     * later in the same {@code onLoop} ends early with
     * {@link InterruptedException}. Return from {@code onLoop} promptly after
     * calling it.</p>
     *
     * <p>Use this for self-stop conditions detected in deep call sites
     * (controllers, sub-tasks) where bubbling {@code -1} back up to the top-level
     * loop is awkward. It does <b>not</b> grant peer-stop capability — a
     * BotScript still cannot terminate other scripts on the same Client. For
     * cross-script control use {@link com.botwithus.bot.api.script.ManagementContext}
     * from a {@link com.botwithus.bot.api.script.ManagementScript}.</p>
     *
     * <p>The default implementation is a no-op so unit tests instantiating their
     * own {@code ScriptContext} don't have to wire the stop pathway. The real
     * runtime overrides this.</p>
     */
    default void stopSelf() {
    }

    /**
     * The display name of the character on this script's client, once the host knows it.
     *
     * <p>Same value as {@link Client#getDisplayName()} for the client this script runs on.
     * When the client was launched for a known Jagex character, the name is available from
     * the login screen on; otherwise it is empty until the client is in a world. In a
     * world the logged-in character's name wins over the launched one, and it is
     * refreshed after a later login. Cheap to call from {@code onLoop}: it never blocks on
     * the client.</p>
     *
     * <p>The default returns empty, for contexts that are not bound to a live game client
     * (test mocks).</p>
     *
     * @return the character's display name, or empty while it is not known
     */
    default Optional<String> getDisplayName() {
        return Optional.empty();
    }
}
