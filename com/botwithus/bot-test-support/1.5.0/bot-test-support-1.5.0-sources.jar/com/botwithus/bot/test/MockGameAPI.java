package com.botwithus.bot.test;

import com.botwithus.bot.api.GameAPI;
import com.botwithus.bot.api.component.Components;
import com.botwithus.bot.api.draw.Draw;
import com.botwithus.bot.api.draw.DrawBatchResult;
import com.botwithus.bot.api.draw.DrawCommand;
import com.botwithus.bot.api.draw.DrawEntry;
import com.botwithus.bot.api.draw.DrawStats;
import com.botwithus.bot.api.entities.GroundItems;
import com.botwithus.bot.api.entities.Npcs;
import com.botwithus.bot.api.entities.Players;
import com.botwithus.bot.api.entities.Projectiles;
import com.botwithus.bot.api.entities.SceneObjects;
import com.botwithus.bot.api.entities.WorldMapElements;
import com.botwithus.bot.api.input.InputDialog;
import com.botwithus.bot.api.inventory.Backpack;
import com.botwithus.bot.api.inventory.Bank;
import com.botwithus.bot.api.inventory.Equipment;
import com.botwithus.bot.api.model.ActionEntry;
import com.botwithus.bot.api.model.Component;
import com.botwithus.bot.api.model.ComponentOps;
import com.botwithus.bot.api.model.ComponentRef;
import com.botwithus.bot.api.model.ComponentTreeNode;
import com.botwithus.bot.api.model.EntityKind;
import com.botwithus.bot.api.model.EntityRead;
import com.botwithus.bot.api.model.EnumType;
import com.botwithus.bot.api.model.GameAction;
import com.botwithus.bot.api.model.Headbar;
import com.botwithus.bot.api.model.HintArrow;
import com.botwithus.bot.api.model.ItemType;
import com.botwithus.bot.api.model.LocationType;
import com.botwithus.bot.api.model.LoginState;
import com.botwithus.bot.api.model.NpcType;
import com.botwithus.bot.api.model.OverheadText;
import com.botwithus.bot.api.model.PathResult;
import com.botwithus.bot.api.model.PlayerStat;
import com.botwithus.bot.api.model.QuestType;
import com.botwithus.bot.api.model.ScriptResult;
import com.botwithus.bot.api.model.SequenceType;
import com.botwithus.bot.api.model.SpotAnimation;
import com.botwithus.bot.api.model.StructType;
import com.botwithus.bot.api.model.VarbitRead;
import com.botwithus.bot.api.model.VarbitValue;
import com.botwithus.bot.api.model.VarpRead;
import com.botwithus.bot.api.model.WalkStatus;
import com.botwithus.bot.api.model.WorldMapElement;
import com.botwithus.bot.api.model.WorldPathConfig;
import com.botwithus.bot.api.snapshot.GameSnapshot;
import com.botwithus.bot.api.model.PlayerAppearance;
import com.botwithus.bot.api.snapshot.LocalPlayer;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.function.Supplier;

/**
 * Minimal {@link GameAPI} stub for dry-run script tests.
 *
 * <p>Only the methods a typical {@code onStart}/{@code onLoop}/{@code onStop}
 * actually call are implemented:
 * <ul>
 *   <li>{@link #snapshot()} — delegates to the configured supplier</li>
 *   <li>{@link #getLocalPlayer()} — returns {@code snapshot().self()}. There is
 *       no pipe here, so health is whatever the canned {@code LocalPlayer}
 *       carries: build it with the values your test wants to exercise rather
 *       than expecting the mock to fill them in</li>
 *   <li>{@link #queueAction(GameAction)} — forwards to the recording sink</li>
 *   <li>{@link #queueActions(List)} — forwarded one-by-one to the sink</li>
 * </ul>
 *
 * <p>Every other method throws {@link UnsupportedOperationException} with a
 * pointer at which seam to configure. The intent is exactly the opposite of
 * a "friendly mock that returns sensible defaults" — tests should be loud
 * about what they exercise. If your script reaches an unstubbed method, that
 * is a signal the test needs to either supply a real {@link GameAPI} or the
 * script needs to be split into a smaller unit.</p>
 */
final class MockGameAPI implements GameAPI {

    private final Supplier<GameSnapshot> snapshotSource;
    private final Consumer<GameAction> actionSink;

    MockGameAPI(Supplier<GameSnapshot> snapshotSource, Consumer<GameAction> actionSink) {
        if (snapshotSource == null) {
            throw new IllegalArgumentException("snapshotSource");
        }
        if (actionSink == null) {
            throw new IllegalArgumentException("actionSink");
        }
        this.snapshotSource = snapshotSource;
        this.actionSink = actionSink;
    }

    private static UnsupportedOperationException notStubbed(String method) {
        return new UnsupportedOperationException(
                "MockGameAPI." + method + " not stubbed — provide a real GameAPI for tests that reach this seam");
    }

    @Override
    public GameSnapshot snapshot() {
        return snapshotSource.get();
    }

    @Override
    public LocalPlayer getLocalPlayer() {
        GameSnapshot snap = snapshot();
        return snap == null ? null : snap.self();
    }

    @Override
    public void queueAction(GameAction action) {
        actionSink.accept(action);
    }

    @Override
    public int queueActions(List<GameAction> actions) {
        actions.forEach(actionSink);
        return actions.size();
    }

    // ---- SystemAPI ---------------------------------------------------------

    @Override
    public boolean ping() {
        throw notStubbed("ping");
    }

    @Override
    public List<String> listMethods() {
        throw notStubbed("listMethods");
    }

    @Override
    public int getClientCount() {
        throw notStubbed("getClientCount");
    }

    // ---- ActionAPI ---------------------------------------------------------

    @Override
    public int getActionQueueSize() {
        throw notStubbed("getActionQueueSize");
    }

    @Override
    public void clearActionQueue() {
        throw notStubbed("clearActionQueue");
    }

    @Override
    public List<ActionEntry> getActionHistory(int maxResults, int actionIdFilter) {
        throw notStubbed("getActionHistory");
    }

    @Override
    public long getLastActionTime() {
        throw notStubbed("getLastActionTime");
    }

    @Override
    public boolean areActionsBlocked() {
        throw notStubbed("areActionsBlocked");
    }

    @Override
    public void setActionsBlocked(boolean blocked) {
        throw notStubbed("setActionsBlocked");
    }

    // ---- NavigationAPI -----------------------------------------------------

    @Override
    public void walkToAsync(int x, int y) {
        throw notStubbed("walkToAsync");
    }

    @Override
    public void walkWorldPathAsync(int x, int y, int plane) {
        throw notStubbed("walkWorldPathAsync");
    }

    @Override
    public void walkWorldPathAsync(int x, int y, int plane, boolean exactDestTile, WorldPathConfig config) {
        throw notStubbed("walkWorldPathAsync");
    }

    @Override
    public void walkCancel() {
        throw notStubbed("walkCancel");
    }

    @Override
    public WalkStatus getWalkStatus() {
        throw notStubbed("getWalkStatus");
    }

    @Override
    public long walkRefusalCount() {
        throw notStubbed("walkRefusalCount");
    }

    @Override
    public boolean isReachable(int x, int y) {
        throw notStubbed("isReachable");
    }

    @Override
    public boolean isReachable(int x, int y, int maxIterations) {
        throw notStubbed("isReachable");
    }

    @Override
    public PathResult findPath(int toX, int toY) {
        throw notStubbed("findPath");
    }

    @Override
    public PathResult findPath(int fromX, int fromY, int toX, int toY) {
        throw notStubbed("findPath");
    }

    @Override
    public PathResult findWorldPath(int toX, int toY) {
        throw notStubbed("findWorldPath");
    }

    @Override
    public PathResult findWorldPath(int fromX, int fromY, int toX, int toY) {
        throw notStubbed("findWorldPath");
    }

    @Override
    public int getRegionCacheSize() {
        throw notStubbed("getRegionCacheSize");
    }

    @Override
    public void clearRegionCache() {
        throw notStubbed("clearRegionCache");
    }

    // ---- Entity / inventory facades ----------------------------------------

    @Override
    public Npcs npcs() {
        throw notStubbed("npcs");
    }

    @Override
    public Players players() {
        throw notStubbed("players");
    }

    @Override
    public Backpack backpack() {
        throw notStubbed("backpack");
    }

    @Override
    public Bank bank() {
        throw notStubbed("bank");
    }

    @Override
    public InputDialog inputDialog() {
        throw notStubbed("inputDialog");
    }

    @Override
    public Equipment equipment() {
        throw notStubbed("equipment");
    }

    @Override
    public SceneObjects objects() {
        throw notStubbed("objects");
    }

    @Override
    public GroundItems groundItems() {
        throw notStubbed("groundItems");
    }

    @Override
    public Projectiles projectiles() {
        throw notStubbed("projectiles");
    }

    @Override
    public List<SpotAnimation> querySpotAnims() {
        throw notStubbed("querySpotAnims");
    }

    @Override
    public WorldMapElements mapElements() {
        throw notStubbed("mapElements");
    }

    @Override
    public List<WorldMapElement> queryWorldMapElements(Map<String, Object> filter) {
        throw notStubbed("queryWorldMapElements");
    }

    @Override
    public PlayerStat getPlayerStat(int skillId) {
        throw notStubbed("getPlayerStat");
    }

    // ---- State probes ------------------------------------------------------

    @Override
    public int getGameCycle() {
        throw notStubbed("getGameCycle");
    }

    @Override
    public LoginState getLoginState() {
        throw notStubbed("getLoginState");
    }

    // ---- Login / breaks ----------------------------------------------------

    @Override
    public void setWorld(int worldId) {
        throw notStubbed("setWorld");
    }

    @Override
    public void changeLoginState(int oldState, int newState) {
        throw notStubbed("changeLoginState");
    }

    @Override
    public void loginToLobby() {
        throw notStubbed("loginToLobby");
    }

    @Override
    public void scheduleBreak(int durationMs) {
        throw notStubbed("scheduleBreak");
    }

    @Override
    public void interruptBreak() {
        throw notStubbed("interruptBreak");
    }

    @Override
    public boolean getAutoLogin() {
        throw notStubbed("getAutoLogin");
    }

    @Override
    public void setAutoLogin(boolean enabled) {
        throw notStubbed("setAutoLogin");
    }

    // ---- Script execution --------------------------------------------------

    @Override
    public long getScriptHandle(int scriptId) {
        throw notStubbed("getScriptHandle");
    }

    @Override
    public ScriptResult executeScript(long handle, int[] intArgs, String[] stringArgs, String[] returns) {
        throw notStubbed("executeScript");
    }

    @Override
    public void destroyScriptHandle(long handle) {
        throw notStubbed("destroyScriptHandle");
    }

    @Override
    public void fireComponentTrigger(int interfaceId, int componentId, int subId,
                                     int triggerType, int arg) {
        throw notStubbed("fireComponentTrigger");
    }

    // ---- Interface tree walk -----------------------------------------------

    @Override
    public PlayerAppearance getPlayerAppearance(int serverIndex) {
        throw notStubbed("getPlayerAppearance");
    }

    @Override
    public EntityRead<Optional<OverheadText>> getOverheadText(EntityKind kind, int serverIndex) {
        throw notStubbed("getOverheadText");
    }

    @Override
    public EntityRead<List<Headbar>> getHeadbars(EntityKind kind, int serverIndex) {
        throw notStubbed("getHeadbars");
    }

    @Override
    public EntityRead<List<HintArrow>> queryHintArrows() {
        throw notStubbed("queryHintArrows");
    }

    @Override
    public Component getComponent(int interfaceId, int componentId) {
        throw notStubbed("getComponent");
    }

    @Override
    public Component findComponentAt(int screenX, int screenY) {
        throw notStubbed("findComponentAt");
    }

    @Override
    public List<Component> getComponents(List<ComponentRef> refs) {
        throw notStubbed("getComponents");
    }

    @Override
    public List<Integer> getStaticChildren(int interfaceId, int componentId) {
        throw notStubbed("getStaticChildren");
    }

    @Override
    public List<Integer> getDynamicChildren(int interfaceId, int componentId) {
        throw notStubbed("getDynamicChildren");
    }

    @Override
    public Components components() {
        throw notStubbed("components");
    }

    // Debug drawing is a producer-side overlay with no in-memory analogue, so
    // every method here is loud rather than a no-op: a script under test that
    // silently "drew" nothing would be worse than one that stops and says so.

    @Override
    public Draw draw() {
        throw notStubbed("draw");
    }

    @Override
    public String drawSet(DrawCommand.Primitive command) {
        throw notStubbed("drawSet");
    }

    @Override
    public DrawBatchResult drawSetBatch(List<DrawCommand.Primitive> commands) {
        throw notStubbed("drawSetBatch");
    }

    @Override
    public String drawHighlight(DrawCommand.Highlight highlight) {
        throw notStubbed("drawHighlight");
    }

    @Override
    public DrawBatchResult drawHighlights(List<DrawCommand.Highlight> highlights) {
        throw notStubbed("drawHighlights");
    }

    @Override
    public int drawClear(List<String> keys) {
        throw notStubbed("drawClear");
    }

    @Override
    public int drawClearAll() {
        throw notStubbed("drawClearAll");
    }

    @Override
    public List<DrawEntry> drawList() {
        throw notStubbed("drawList");
    }

    @Override
    public boolean isDrawEnabled() {
        throw notStubbed("isDrawEnabled");
    }

    @Override
    public boolean setDrawEnabled(boolean enabled) {
        throw notStubbed("setDrawEnabled");
    }

    @Override
    public DrawStats drawStats() {
        throw notStubbed("drawStats");
    }

    @Override
    public List<ComponentTreeNode> getInterfaceTree(int interfaceId, int componentId) {
        throw notStubbed("getInterfaceTree");
    }

    // ---- Config-type lookups -----------------------------------------------

    @Override
    public ItemType getItemType(int id) {
        throw notStubbed("getItemType");
    }

    @Override
    public NpcType getNpcType(int id) {
        throw notStubbed("getNpcType");
    }

    @Override
    public LocationType getLocationType(int id) {
        throw notStubbed("getLocationType");
    }

    @Override
    public EnumType getEnumType(int id) {
        throw notStubbed("getEnumType");
    }

    @Override
    public StructType getStructType(int id) {
        throw notStubbed("getStructType");
    }

    @Override
    public SequenceType getSequenceType(int id) {
        throw notStubbed("getSequenceType");
    }

    @Override
    public QuestType getQuestType(int id) {
        throw notStubbed("getQuestType");
    }

    // ---- Game variables (varp / varc / varbit) -----------------------------

    @Override
    public int getVarp(int varId) {
        throw notStubbed("getVarp");
    }

    @Override
    public long getVarpLong(int varId) {
        throw notStubbed("getVarpLong");
    }

    @Override
    public VarpRead readVarp(int varId) {
        throw notStubbed("readVarp");
    }

    @Override
    public List<VarpRead> readVarps(List<Integer> varIds) {
        throw notStubbed("readVarps");
    }

    @Override
    public VarbitRead readVarbit(int varbitId) {
        throw notStubbed("readVarbit");
    }

    @Override
    public List<VarbitRead> readVarbits(List<Integer> varbitIds) {
        throw notStubbed("readVarbits");
    }

    @Override
    public int getVarbit(int varbitId) {
        throw notStubbed("getVarbit");
    }

    @Override
    public int getVarcInt(int varcId) {
        throw notStubbed("getVarcInt");
    }

    @Override
    public String getVarcString(int varcId) {
        throw notStubbed("getVarcString");
    }

    @Override
    public List<VarbitValue> queryVarbits(List<Integer> varbitIds) {
        throw notStubbed("queryVarbits");
    }

    @Override
    public ComponentOps getComponentOps(int interfaceId, int componentId, int sub) {
        throw notStubbed("getComponentOps");
    }

    @Override
    public Map<Integer, Map<Integer, Integer>> getObjVars(int invId) {
        throw notStubbed("getObjVars");
    }

    @Override
    public Map<Integer, Integer> getObjVars(int invId, int slot) {
        throw notStubbed("getObjVars");
    }

    @Override
    public List<Integer> getVarps(List<Integer> varIds) {
        throw notStubbed("getVarps");
    }

    @Override
    public List<Integer> getVarcInts(List<Integer> varcIds) {
        throw notStubbed("getVarcInts");
    }

    @Override
    public List<String> getVarcStrings(List<Integer> varcIds) {
        throw notStubbed("getVarcStrings");
    }
}
